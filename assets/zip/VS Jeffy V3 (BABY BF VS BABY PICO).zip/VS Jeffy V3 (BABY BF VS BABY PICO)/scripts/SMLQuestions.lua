
local allowEndSong = false
local imageShown = false

function onCreate()

    folderPath = 'smlquestions/' 
    
   
    imageFiles = {}

   
    local startNumber = 1
    local endNumber = 25

    
    for i = startNumber, endNumber do
        table.insert(imageFiles, tostring(i))
    end
end

function onEndSong()
    

    if songName == "Real Boy" then
        return Function_Continue
    end

    if songName == "kill-jeffy" then
        return Function_Continue
    end

    if (isStoryMode and (songName == 'Bang Em and Slang Em' or songName == 'Run') or not isStoryMode) and not allowEndSong then        
        
        local randomChance = getRandomInt(1, 500)
        if randomChance <= 1 then
            
            makeLuaSprite('secretbg', 'smlquestions/secret/getthisbg', 0, 0)  
            setObjectCamera('secretbg', 'other')
            addLuaSprite('secretbg', true)

         
            playMusic('seceretsmlq', 1, true)

           
            makeAnimatedLuaSprite('secretQuestion', 'smlquestions/secret/getthisapp', 300, 200)
            addAnimationByPrefix('secretQuestion', 'dance', 'getthis', 24, true)
            setObjectCamera('secretQuestion', 'other')
            scaleObject('secretQuestion', 2.5, 2.5) 
            addLuaSprite('secretQuestion', true)

           
            setProperty('inCutscene', true)
            runTimer('endSongDelay', 10) 
        else
            
            local randomIndex = getRandomInt(1, #imageFiles)
            local randomImage = imageFiles[randomIndex]
            
           
            makeLuaSprite('randomImage', folderPath .. randomImage, 0, 0)
            setObjectCamera('randomImage', 'other')
            addLuaSprite('randomImage', true)

          
            playMusic('smlqsong', 1, true)

           
            setProperty('inCutscene', true)
            runTimer('endSongDelay', 8)  
        end
        
      
        return Function_Stop
    end
    return Function_Continue
end

function onUpdate()
   
    if getProperty('inCutscene') and getPropertyFromClass('flixel.FlxG', 'keys.justPressed.BACKSPACE') then
        allowEndSong = true
        endSong()
    end
end

function onTimerCompleted(tag, loops, loopsLeft)
    if tag == 'endSongDelay' then
        
        allowEndSong = true
        setProperty('inCutscene', false)
        endSong()
    end
end
