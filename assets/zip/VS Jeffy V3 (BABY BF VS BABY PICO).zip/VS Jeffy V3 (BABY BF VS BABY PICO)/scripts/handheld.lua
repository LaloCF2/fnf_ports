local shakeIntensity = 4 
local shakeSpeed = 0.1 
local shakeTimer = 0
local followPosX = nil
local followPosY = nil

-- List of songs where the shaking effect should be disabled
local disabledSongs = {
    ["whack-a-bitch"] = true,
    ["kill-jeffy"] = true,
    ["Bang Em and Slang Em"] = true,
    ["Run"] = true
}

function onUpdate(elapsed)
    -- Check if the current song is in the disabled list
    if disabledSongs[songName] then
        return -- Stop execution if the current song is in the list
    end

    followPosX = getProperty('camFollow.x')
    followPosY = getProperty('camFollow.y')

    shakeTimer = shakeTimer + elapsed

    if shakeTimer >= shakeSpeed and getProperty('health') > 0 then
        shakeTimer = 0

        local offsetX = math.random(-shakeIntensity, shakeIntensity)
        local offsetY = math.random(-shakeIntensity, shakeIntensity)

        setProperty('camFollow.x', followPosX + offsetX)
        setProperty('camFollow.y', followPosY + offsetY)
    end
end
