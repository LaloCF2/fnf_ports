function onEvent(name, value1, value2)
	if name == 'Flash' then
	
		color = value1;
		duration = value2;

		cameraFlash('game', 'color', duration, false)
	end
end