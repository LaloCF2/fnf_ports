function onCreate()
    
    makeAnimatedLuaSprite('sleepbubble', 'baby/sleepbubble', 700, 340)  
    addAnimationByPrefix('sleepbubble', 'rise', 'bubble', 24, true)  
    addLuaSprite('sleepbubble', false)
    scaleObject('sleepbubble', 2, 2);
	setProperty('sleepbubble.visible', false)
	
end

function onStepHit()

	if curStep == 768 then
	
	    objectPlayAnimation('sleepbubble', 'rise', true)  

	setProperty('sleepbubble.visible', true)
	
	end
	
end