local credYPosition = 400

function onCreate()

	if downscroll then
		credYPosition = 200
	end


	makeLuaSprite('credit','songcred/credkat',-500, credYPosition)
    setLuaSpriteScrollFactor('credit',0,0)
	setObjectCamera('credit', 'hud')
	addLuaSprite('credit',true)	
	
end



function onStepHit()

	if curStep == 1 then
	

	
	doTweenX('tweencredit','credit', 0, 2, 'expoOut' )
	
	end
	
	
	if curStep == 30 then
	
	doTweenX('tweencredit','credit', -500, 1, 'expoIn' )


	end
	
end