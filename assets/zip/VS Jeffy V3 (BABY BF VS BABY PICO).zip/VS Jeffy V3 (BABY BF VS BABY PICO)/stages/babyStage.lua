local trainSpeed = 150
local trainX = -1300
local trainY = 400
local trainStopped = false

function onCreate()

    makeLuaSprite('bg', 'baby/back', -700, -400)
    addLuaSprite('bg', false)
    scaleObject('bg', 2, 2);
    setScrollFactor('bg', 0.1, 0.1)
	
	makeLuaSprite('Legos', 'baby/legos', -700, -420)
    addLuaSprite('Legos', false)
    scaleObject('Legos', 2, 2);
    setScrollFactor('Legos', 0.5, 0.5)
	
    makeLuaSprite('Floor2', 'baby/floorr', -700, -420)
    addLuaSprite('Floor2', false)
    scaleObject('Floor2', 2, 2);
    setScrollFactor('Floor2', 0.7, 0.7)

    makeLuaSprite('Floor', 'baby/floor', -700, -400)
    addLuaSprite('Floor', false)
    scaleObject('Floor', 2, 2);
    setScrollFactor('Floor', 1.0, 1.0)
	
	makeLuaSprite('Ball', 'baby/ball', -700, 600)
    addLuaSprite('Ball', true)
    scaleObject('Ball', 2, 2);
    setScrollFactor('Ball', 1.3, 1.3)

    makeAnimatedLuaSprite('train', 'baby/train', -1300, 400)
    addAnimationByPrefix('train', 'move', 'tra', 24, true)
    addLuaSprite('train', false)
    scaleObject('train', 2, 2);
    objectPlayAnimation('train', 'move', true)
	
end


function moveTrain(elapsed)

    if not trainStopped then

        trainX = trainX + trainSpeed * elapsed

        if trainX <= 1800 then
            trainY = 0.00005 * (trainX - 350)^2 + 350
            setProperty('train.x', trainX)
            setProperty('train.y', trainY)

            local slope = 2 * 0.00005 * (trainX - 300)
            
            local trainAngle = math.atan(slope) * (180 / math.pi)
            
            setProperty('train.angle', trainAngle)

        else

            trainStopped = true
            runTimer('restartTrain', 3)
            
        end
    end
end

function onUpdate(elapsed)


    moveTrain(elapsed)
end

function onTimerCompleted(tag)
    if tag == 'restartTrain' then
        trainX = -1200
        trainStopped = false
    end
end
