function onCreatePost()
    setPropertyFromClass('Main', 'fpsVar.visible', false)

    makeLuaText('customStats', 'FPS: 0 | RAM: 0 MB', 1280, 10, 10)
    
    setTextSize('customStats', 18)
    setTextAlignment('customStats', 'left')
    setTextBorder('customStats', 2, '000000')
    setObjectCamera('customStats', 'other') 

    addLuaText('customStats')
end


function onUpdatePost(elapsed)
    local fps = getPropertyFromClass('Main', 'fpsVar.currentFPS')
    
    local ramBytes = getPropertyFromClass('openfl.system.System', 'totalMemory')

    local ramMB = math.floor(ramBytes / 1024 / 1024)

    setTextString('customStats', 'FPS: ' .. math.floor(fps) .. ' | RAM: ' .. ramMB .. ' MB')

    if fps < 30 then
        setTextColor('customStats', 'FF0000')
    else
        setTextColor('customStats', 'FFFFFF')
    end
end

function onDestroy()
    setPropertyFromClass('Main', 'fpsVar.visible', true)
end
